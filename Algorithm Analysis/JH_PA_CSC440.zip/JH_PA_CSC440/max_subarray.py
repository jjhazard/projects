def cubic_algorithm(array):
    MaxSoFar = 0.0
    length = len(array)
    for i in range(length):
        for j in range(i, length+1):
            total = 0.0
            for k in range(i, j):
                total += float(array[k])
                if MaxSoFar < total:
                    MaxSoFar = total
    return MaxSoFar
                  
def quadratic_algorithm_1(array):
    MaxSoFar = 0.0
    length = len(array)
    for i in range(0, length+1):
        total = 0.0
        for j in range(i, length):
            total += float(array[j])
            if MaxSoFar < total:
                MaxSoFar = total
    return MaxSoFar

def quadratic_algorithm_2(array):
    length = len(array)
    CumArray = [float(array[0])]
    MaxSoFar = -100000.0
    for i in range(1, length):
        CumArray += [CumArray[i - 1] + float(array[i])]
    for i in range(0, length):
        total = CumArray[i]
        if MaxSoFar < total:
            MaxSoFar = total
        for j in range(i+1, length):
            total = CumArray[j] - CumArray[i]
            if MaxSoFar < total:
                MaxSoFar = total
    return MaxSoFar

def divide_and_conquer_algorithm(array):
    def MaxSum(array, L, U):
        if L > U:
            return 0.0
        if L == U:
            if float(array[L]) > 0.0:
                return float(array[L])
            else:
                return 0.0
        M = ( L + U ) // 2
        total = 0.0
        MaxToLeft = 0.
        for i in range(M, L-1, -1):
            total += float(array[i])
            if MaxToLeft < total:
                MaxToLeft = total
        total = 0.0
        MaxToRight = 0.
        for i in range((M + 1), U+1):
            total += float(array[i])
            if MaxToRight < total:
                MaxToRight = total
        MaxCrossing = MaxToLeft + MaxToRight
        MaxInL = MaxSum(array, L, M);
        MaxInR = MaxSum(array, (M + 1), U);
        if (MaxCrossing < MaxInL):
            MaxCrossing = MaxInL
        if (MaxCrossing < MaxInR):
            MaxCrossing = MaxInR
        return MaxCrossing
    return MaxSum(array, 0, (len(array) - 1))

def linear_algorithm(array):
    MaxSoFar = -100000.0
    MaxEndingHere = 0.0
    for i in range(len(array)):
        MaxEndingHere += float(array[i])
        if MaxEndingHere < 0.0:
            MaxEndingHere = 0.0
        if MaxSoFar < MaxEndingHere:
            MaxSoFar = MaxEndingHere
    return MaxSoFar
